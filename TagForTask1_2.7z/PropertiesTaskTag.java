package com.company.AEMTraining.taglib;

import com.squeakysand.jsp.tagext.annotations.JspTagAttribute;
import org.apache.sling.api.SlingHttpServletRequest;

import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import javax.servlet.jsp.JspException;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.jcr.Node;
import javax.servlet.jsp.tagext.DynamicAttributes;
import javax.servlet.jsp.tagext.TagSupport;

/**
 * Created by Hanna_Sushchanka on 7/14/2014.
 */

public class PropertiesTaskTag extends TagSupport implements DynamicAttributes {
    private Map<String, Object> inputMap = new LinkedHashMap<String, Object>();

    @Override
    public int doStartTag() throws JspException {
        Map<String, Object> outputMap = new LinkedHashMap<String, Object>();
        try {
            for ( String name : inputMap.keySet()){
                Node eachNode = ((SlingHttpServletRequest)pageContext.getRequest()).getResourceResolver().getResource((String) inputMap.get(name)).adaptTo(Node.class);
                NodeIterator it = eachNode.getNodes();
                if(it.hasNext()){
                    it.nextNode();
                }
                while (it.hasNext()){
                    Node node = it.nextNode();
                    outputMap.put(node.getName(), node.getPath());
                }
                pageContext.setAttribute(name, outputMap );
            }
        } catch (RepositoryException e) {
            e.printStackTrace();
        }
        return SKIP_BODY;
    }

    @JspTagAttribute ()
    public void setDynamicAttribute(String arg0, String name, Object value)
            throws JspException {
        inputMap.put(name, value);
    }
}
