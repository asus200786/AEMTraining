package com.company.AEMTraining.taglib;

import com.cqblueprints.taglib.CqSimpleTagSupport;
import com.squeakysand.jsp.tagext.annotations.JspTag;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.wrappers.ValueMapDecorator;

import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;
import java.io.IOException;
import java.util.LinkedHashMap;

import javax.jcr.Node;


/**
 * Created by Hanna_Sushchanka on 7/14/2014.
 */

@JspTag
public class PropertiesTask extends CqSimpleTagSupport {

    private ValueMap inputMapValue = new ValueMapDecorator(new LinkedHashMap<String, Object>());;
    private ValueMap outputMapValue;


    @Override
    public void doTag() throws IOException, JspException {
        try {

            outputMapValue = new ValueMapDecorator(new LinkedHashMap<String, Object>());
            for (String name : inputMapValue.keySet()) {

                PageContext pageContext = getPageContext();
                ResourceResolver resourceResolver = ((SlingHttpServletRequest) pageContext.getRequest()).getResourceResolver();
                Resource resource = resourceResolver.getResource((String) inputMapValue.get(name));
                Node currentNode = resource.adaptTo(Node.class);
                getJspWriter().write("CurrentNode" + currentNode);
                NodeIterator nodeIterator = currentNode.getNodes();
                getJspWriter().write("NodeIterator" + currentNode);

                if (nodeIterator.hasNext()) {
                    nodeIterator.nextNode();
                }

                while (nodeIterator.hasNext()) {
                    Node node = nodeIterator.nextNode();

                    outputMapValue.put(node.getName(), node.getPath());
                    getJspWriter().write("PathNode"+node.getPath());
                    pageContext.setAttribute(name, outputMapValue);
                }
            }
        } catch (RepositoryException e) {
            e.printStackTrace();
        }
    }

    public void setDynamicAttribute(String arg, String name, Object value) {
        inputMapValue.put(name, value);
    }
}
